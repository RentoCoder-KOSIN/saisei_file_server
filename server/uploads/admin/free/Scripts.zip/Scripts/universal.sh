#!/bin/bash

# ===============================================================
# 万能開発コンソール v3.6 (完全版・無省略・日本語)
# 統合環境: Starship + ble.sh + Neovim 0.11 IDE + 開発ツール
# ===============================================================

set -euo pipefail

# ----- 設定パス -----
CONFIG_DIR="$HOME/.config"
NVIM_CONFIG_DIR="$HOME/.config/nvim"
LAZY_PATH="$HOME/.local/share/nvim/lazy/lazy.nvim"

# ----- sudo 権限の自動維持 -----
sudo -v || true
( while true; do sudo -n true; sleep 60; done ) 2>/dev/null &
SUDO_LOOP_PID=$!

# 終了時のクリーンアップ
cleanup() {
    echo -e "\n${YELLOW}終了中... バックグラウンドプロセスを停止します。${NORMAL}"
    kill $SUDO_LOOP_PID 2>/dev/null || true
    exit
}
trap cleanup INT TERM EXIT

# ===== カラー設定 =====
if command -v tput >/dev/null; then
    BOLD=$(tput bold); NORMAL=$(tput sgr0); RED=$(tput setaf 1); GREEN=$(tput setaf 2)
    YELLOW=$(tput setaf 3); MAGENTA=$(tput setaf 5); CYAN=$(tput setaf 6); BLUE=$(tput setaf 4)
else
    BOLD=""; NORMAL=""; RED=""; GREEN=""; YELLOW=""; MAGENTA=""; CYAN=""; BLUE=""
fi

# ===== 共通UI関数 =====
print_header() {
    command -v clear >/dev/null && clear
    echo "${MAGENTA}${BOLD}╔══════════════════════════════════════════════════════════╗${NORMAL}"
    echo "${MAGENTA}${BOLD}║              🚀 万能開発コンソール v3.6                  ║${NORMAL}"
    echo "${MAGENTA}${BOLD}║           Stable + SSH + UI Enhanced + 0.11 Ready        ║${NORMAL}"
    echo "${MAGENTA}${BOLD}╚══════════════════════════════════════════════════════════╝${NORMAL}"
}

pause() { echo ""; read -r -p "${CYAN}Enterキーを押して戻る...${NORMAL}" || true; }
safe_read() { read -r -p "$1" REPLY || REPLY=""; echo "$REPLY"; }
loading() { echo -n "${CYAN}$1${NORMAL}"; for _ in {1..4}; do echo -n "."; sleep 0.2; done; echo " 完了!"; }

# ===== [1] システム管理 =====
system_update() { loading "システムを更新中"; sudo apt update && sudo apt upgrade -y; }
disk_status() { 
    echo "${BLUE}--- ストレージ状況 ---${NORMAL}"; df -h | grep '^/dev/'
    echo "${BLUE}--- メモリ状況 ---${NORMAL}"; free -h
}
network_info() { echo "${BLUE}--- ネットワーク ---${NORMAL}"; ip -brief addr; }

# ===== [2] Python環境 =====
# Python 3.12 共通インストール関数 (pyenv経由・Debian/Chromebook対応)
install_python312() {
    local PYVER="3.12.10"

    # すでに3.12が入っていればスキップ
    if command -v python3.12 &>/dev/null; then
        echo "${GREEN}  Python 3.12 すでにインストール済み: $(python3.12 --version)${NORMAL}"
        sudo update-alternatives --install /usr/bin/python3 python3 "$(command -v python3.12)" 100 2>/dev/null || true
        sudo update-alternatives --set python3 "$(command -v python3.12)" 2>/dev/null || true
        return
    fi

    loading "pyenv のビルド依存パッケージをインストール中"
    sudo apt-get install -y \
        build-essential libssl-dev zlib1g-dev libbz2-dev \
        libreadline-dev libsqlite3-dev libncursesw5-dev \
        xz-utils tk-dev libxml2-dev libxmlsec1-dev libffi-dev liblzma-dev

    loading "pyenv をインストール中"
    if [ ! -d "$HOME/.pyenv" ]; then
        curl -fsSL https://pyenv.run | bash
    fi
    export PYENV_ROOT="$HOME/.pyenv"
    export PATH="$PYENV_ROOT/bin:$PATH"
    eval "$(pyenv init -)"

    # ~/.bashrc に追記（重複しない）
    grep -q 'pyenv init' ~/.bashrc || cat >> ~/.bashrc << 'BASHRC'
export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"
BASHRC

    loading "Python ${PYVER} をビルド中 (数分かかります)"
    pyenv install -s "$PYVER"
    pyenv global "$PYVER"

    # /usr/local/bin にシンボリックリンクを置いてシステム全体から参照可能に
    sudo ln -sf "$HOME/.pyenv/shims/python3.12" /usr/local/bin/python3.12 2>/dev/null || true
    sudo ln -sf "$HOME/.pyenv/shims/python3"    /usr/local/bin/python3    2>/dev/null || true
    sudo ln -sf "$HOME/.pyenv/shims/pip3"       /usr/local/bin/pip3       2>/dev/null || true

    # pip を最新に
    python3.12 -m pip install --upgrade pip --quiet

    echo "${GREEN}  Python: $(python3.12 --version)${NORMAL}"
}

python_install() {
    install_python312
    python3.12 -m pip install requests PyPDF2 Pillow watchdog --quiet
}
create_venv() { 
    name=$(safe_read "仮想環境名を入力 (デフォルト: .venv) > ")
    name=${name:-.venv}
    python3 -m venv "$name"
    echo "${GREEN}作成完了: $name${NORMAL}"
}
pip_install() { 
    pkg=$(safe_read "インストールするパッケージ名 > ")
    [ -n "$pkg" ] && python3 -m pip install "$pkg"
}
run_python() { 
    file=$(safe_read "実行するPythonファイル > ")
    [ -f "$file" ] && python3 "$file" || echo "${RED}ファイルが見つかりません${NORMAL}"
}

# ===== [3] Node.js環境 =====
node_install() { 
    loading "Node.js 22 (LTS)をインストール中"
    curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
    sudo apt install -y nodejs
    node -v && npm -v
}
create_express() {
    echo "Expressサーバーを作成中..."
    [ -f package.json ] || npm init -y >/dev/null
    npm install express
    cat > index.js << "EOF"
const express = require("express");
const app = express();
app.get("/", (req, res) => res.send("Hello Dev Console!"));
app.listen(3000, () => { console.log("Server running at http://localhost:3000"); });
EOF
    echo "${GREEN}index.js (Express) を作成しました${NORMAL}"
}
kill_node() { 
    port=$(safe_read "停止するポート番号 (デフォルト: 3000) > ")
    port=${port:-3000}
    sudo lsof -ti:"$port" | xargs -r kill -9 2>/dev/null && echo "${GREEN}ポート $port を解放しました${NORMAL}" || echo "${RED}プロセスが見つかりません${NORMAL}"
}

# ===== [4] Git & ファイル管理 =====
git_setup() {
    sudo apt install -y git
    name=$(safe_read "Git ユーザー名 > ")
    mail=$(safe_read "Git メールアドレス > ")
    git config --global user.name "$name"
    git config --global user.email "$mail"
    echo "${GREEN}Git設定を保存しました${NORMAL}"
}
file_search() { 
    dir=$(safe_read "検索ディレクトリ > ")
    [ -d "$dir" ] && find "$dir" -maxdepth 2 -type f \( -name "*.sh" -o -name "*.py" -o -name "*.js" \)
}
archive_make() { 
    d=$(safe_read "圧縮する対象ディレクトリ > ")
    [ -d "$d" ] && tar czvf "archive_$(date +%F_%H%M).tar.gz" "$d"
}
backup_home() { 
    loading "ホームディレクトリをバックアップ中"
    tar czvf "backup_$(date +%F).tar.gz" --exclude=.cache --exclude=.venv "$HOME" 2>/dev/null
    echo "${GREEN}バックアップ完了: backup_$(date +%F).tar.gz${NORMAL}"
}

# ===== [5] 開発ツール =====
install_vscode() {
    loading "VSCodeをインストール中"
    wget -qO- https://packages.microsoft.com/keys/microsoft.asc | sudo gpg --dearmor -o /usr/share/keyrings/microsoft.gpg
    echo "deb [arch=amd64 signed-by=/usr/share/keyrings/microsoft.gpg] https://packages.microsoft.com/repos/code stable main" | sudo tee /etc/apt/sources.list.d/vscode.list > /dev/null
    sudo apt update && sudo apt install -y code
}
install_ngrok() {
    loading "Ngrokをインストール中"
    curl -sSL https://ngrok-agent.s3.amazonaws.com/ngrok.asc | sudo tee /etc/apt/trusted.gpg.d/ngrok.asc >/dev/null
    echo "deb https://ngrok-agent.s3.amazonaws.com bookworm main" | sudo tee /etc/apt/sources.list.d/ngrok.list
    sudo apt update && sudo apt install ngrok
    token=$(safe_read "Ngrok Authtokenを入力してください > ")
    [ -n "$token" ] && ngrok config add-authtoken "$token"
}

# ===== [6] シェル強化 (Starship + ble.sh) =====
install_shell_enhancements() {
    loading "Starshipをインストール中"
    curl -sS https://starship.rs/install.sh | sh -s -- -y
    mkdir -p ~/.config
    starship preset pastel-powerline -o ~/.config/starship.toml

    loading "ble.sh をビルド中"
    sudo apt install -y gawk make
    [ -d "ble.sh" ] && rm -rf ble.sh
    git clone --recursive --depth 1 https://github.com/akinomyoga/ble.sh.git
    cd ble.sh && make install PREFIX=~/.local && cd .. && rm -rf ble.sh

    if ! grep -q "blesh/ble.sh" ~/.bashrc; then
        sed -i '1i [[ -f ~/.local/share/blesh/ble.sh ]] && source ~/.local/share/blesh/ble.sh' ~/.bashrc
    fi
    if ! grep -q "starship init bash" ~/.bashrc; then
        cat >> ~/.bashrc << 'EOF'
eval "$(starship init bash)"
if [[ ${BLE_VERSION-} ]]; then
    ble-face auto_complete='fg=12,italic'
fi
EOF
    fi
    echo "${GREEN}シェルUIの強化が完了しました。再起動後に反映されます。${NORMAL}"
}

# ===== [7] Neovim 0.11 IDE 完全構築 (ファイル生成) =====
write_nvim_files() {
    mkdir -p "$NVIM_CONFIG_DIR/lua/config"

    # init.lua
    cat > "$NVIM_CONFIG_DIR/init.lua" <<'EOF'
require("config.options")
require("config.keymaps")
require("config.lazy")
require("config.plugins")
vim.defer_fn(function()
    require("config.lsp")
    require("config.cmp")
    pcall(require, "config.treesitter")
end, 100)
EOF

    # options.lua
    cat > "$NVIM_CONFIG_DIR/lua/config/options.lua" <<'EOF'
local opt = vim.opt
vim.g.mapleader = " "
opt.number = true
opt.relativenumber = true
opt.clipboard = "unnamedplus"
opt.tabstop = 4
opt.shiftwidth = 4
opt.expandtab = true
opt.smartindent = true
opt.termguicolors = true
opt.cursorline = true
opt.signcolumn = "yes"
opt.undofile = true
opt.ignorecase = true
opt.smartcase = true
EOF

    # keymaps.lua
    cat > "$NVIM_CONFIG_DIR/lua/config/keymaps.lua" <<'EOF'
local map = vim.keymap.set
map("n", "<leader>w", ":w<CR>", { desc = "保存" })
map("n", "<leader>q", ":q<CR>", { desc = "閉じる" })
map("n", "<leader>e", ":NvimTreeToggle<CR>", { desc = "ファイルツリー" })
map("n", "<leader>ff", ":Telescope find_files<CR>", { desc = "ファイル検索" })
map("n", "<leader>fg", ":Telescope live_grep<CR>", { desc = "文字列検索" })
map("i", "jk", "<Esc>", { desc = "挿入モードを抜ける" })
map("n", "<C-h>", "<C-w>h")
map("n", "<C-j>", "<C-w>j")
map("n", "<C-k>", "<C-w>k")
map("n", "<C-l>", "<C-w>l")
EOF

    # lazy.lua
    cat > "$NVIM_CONFIG_DIR/lua/config/lazy.lua" <<'EOF'
local lazypath = vim.fn.stdpath("data").."/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
  vim.fn.system({"git","clone","--filter=blob:none","https://github.com/folke/lazy.nvim.git",lazypath})
end
vim.opt.rtp:prepend(lazypath)
EOF

    # plugins.lua
    cat > "$NVIM_CONFIG_DIR/lua/config/plugins.lua" <<'EOF'
require("lazy").setup({
    -- テーマ
    {"folke/tokyonight.nvim", lazy = false, priority = 1000, config = function() vim.cmd[[colorscheme tokyonight-storm]] end},
    -- ファイラ
    {"nvim-tree/nvim-tree.lua", dependencies={"nvim-tree/nvim-web-devicons"}, config=function() require("nvim-tree").setup() end},
    -- ステータスライン
    {"nvim-lualine/lualine.nvim", config=function() require("lualine").setup() end},
    -- UI 通知
    {"folke/noice.nvim", event = "VeryLazy", dependencies = {"MunifTanjim/nui.nvim", "rcarriga/nvim-notify"}, config = function() require("noice").setup() end},
    -- シンタックスハイライト
    {"nvim-treesitter/nvim-treesitter", build=":TSUpdate"},
    -- 検索
    {"nvim-telescope/telescope.nvim", dependencies={"nvim-lua/plenary.nvim"}},

    {
        "windwp/nvim-autopairs",
        event = "InsertEnter",
        config = function()
            require("nvim-autopairs").setup({})
        end
    },

-- LSP 基盤
    {"neovim/nvim-lspconfig"},
    {"williamboman/mason.nvim", config=function() require("mason").setup() end},
    {"williamboman/mason-lspconfig.nvim", config=function() require("mason-lspconfig").setup({
        ensure_installed={"pyright","clangd","html","cssls","ts_ls","intelephense","gopls"}
    }) end},
    -- 補完エンジン
    {"hrsh7th/nvim-cmp", dependencies={
        "hrsh7th/cmp-nvim-lsp",
        "hrsh7th/cmp-buffer",
        "hrsh7th/cmp-path",
        "saadparwaiz1/cmp_luasnip",
        "L3MON4D3/LuaSnip"
    }},
    -- AI (Copilot)
    {"zbirenbaum/copilot.lua", event="InsertEnter", config=function() require("copilot").setup({suggestion={enabled=false}}) end},
    {"zbirenbaum/copilot-cmp", config=function() require("copilot_cmp").setup() end},
})
EOF

    # cmp.lua
    cat > "$NVIM_CONFIG_DIR/lua/config/cmp.lua" <<'EOF'
local cmp = require("cmp")
local luasnip = require("luasnip")
cmp.setup({
    snippet={expand=function(args) luasnip.lsp_expand(args.body) end},
    mapping=cmp.mapping.preset.insert({
        ["<C-n>"]=cmp.mapping.select_next_item(),
        ["<C-p>"]=cmp.mapping.select_prev_item(),
        ["<CR>"]=cmp.mapping.confirm({select=true}),
        ["<C-Space>"]=cmp.mapping.complete(),
    }),
    sources=cmp.config.sources({
        {name="nvim_lsp", priority=1000},
        {name="copilot",  priority=800},
        {name="luasnip",  priority=500},
        {name="buffer",   priority=250},
        {name="path",     priority=250},
    }),
    window = {
        completion = cmp.config.window.bordered(),
        documentation = cmp.config.window.bordered(),
    }
})

local cmp_autopairs = require("nvim-autopairs.completion.cmp")
cmp.event:on("confirm_done", cmp_autopairs.on_confirm_done())
EOF

    # lsp.lua
    cat > "$NVIM_CONFIG_DIR/lua/config/lsp.lua" <<'EOF'
local lspconfig = require("lspconfig")
local capabilities = require("cmp_nvim_lsp").default_capabilities()
local servers = {"pyright", "clangd", "html", "cssls", "ts_ls", "intelephense", "gopls"}
for _, lsp in ipairs(servers) do
    lspconfig[lsp].setup({ capabilities = capabilities })
end
EOF

    # treesitter.lua
    cat > "$NVIM_CONFIG_DIR/lua/config/treesitter.lua" <<'EOF'
require("nvim-treesitter.configs").setup({
    ensure_installed = {"python","lua","c","cpp","bash","html","css","javascript","json"},
    highlight = { enable = true },
    indent = { enable = true },
    auto_install = true
})
EOF
}

setup_nvim_ide() {
    loading "Neovim 0.11 環境を構築中"
    
    # 基本ツールのインストール
    sudo apt update && sudo apt install -y git curl wget unzip build-essential ripgrep fd-find python3-venv

    # --- nvm の自動インストール / ロード ---
    export NVM_DIR="$HOME/.config/nvm"
    
    if [ ! -s "$NVM_DIR/nvm.sh" ]; then
        loading "nvm をインストールしています..."
        mkdir -p "$NVM_DIR"
        curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | NVM_DIR="$NVM_DIR" bash
    fi

    # 【重要】nvm は set -u と相性が悪いため、一時的に無効化する
    set +u 
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

    if command -v nvm >/dev/null 2>&1; then
        loading "Node.js (LTS) をインストール中..."
        nvm install --lts
        nvm use --lts
        npm install -g tree-sitter-cli neovim
    else
        echo "${RED}エラー: nvm のロードに失敗しました。${NORMAL}"
    fi
    set -u # チェックを再有効化
    # --------------------------------------

    # Neovim 最新バイナリのインストール
    loading "Neovim 0.11 バイナリをダウンロード中..."
    ARCH=$(uname -m)
    case "$ARCH" in
        x86_64)  NVIM_ARCH="x86_64" ;;
        aarch64) NVIM_ARCH="arm64" ;;
        *)       NVIM_ARCH="x86_64" ;;
    esac
    curl -LO "https://github.com/neovim/neovim/releases/latest/download/nvim-linux-${NVIM_ARCH}.tar.gz"
    sudo rm -rf /opt/nvim && sudo mkdir -p /opt/nvim
    sudo tar -C /opt/nvim -xzf "nvim-linux-${NVIM_ARCH}.tar.gz" --strip-components=1
    sudo ln -sf /opt/nvim/bin/nvim /usr/local/bin/nvim
    rm "nvim-linux-${NVIM_ARCH}.tar.gz"

    # fd のエイリアス
    if [ ! -x "$(command -v fd)" ] && [ -x "$(command -v fdfind)" ]; then
        sudo ln -sf /usr/bin/fdfind /usr/local/bin/fd
    fi

    #sudo apt install -y golang-go
    GO_VERSION="1.24.1"
    ARCH=$(uname -m)
    case "$ARCH" in
        x86_64)  GO_ARCH="amd64" ;;
        aarch64) GO_ARCH="arm64" ;;
        *)       GO_ARCH="amd64" ;;
    esac
    wget "https://go.dev/dl/go${GO_VERSION}.linux-${GO_ARCH}.tar.gz"
    sudo rm -rf /usr/local/go
    sudo tar -C /usr/local -xzf "go${GO_VERSION}.linux-${GO_ARCH}.tar.gz"
    rm "go${GO_VERSION}.linux-${GO_ARCH}.tar.gz"
    export PATH=$PATH:/usr/local/go/bin
    grep -q '/usr/local/go/bin' ~/.bashrc || echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
    go install golang.org/x/tools/gopls@latest

    # 設定ファイルの書き出し（ここでフォルダが作られます）
    write_nvim_files
    
    echo "${GREEN}Neovim 0.11 IDE の設定が完了しました。${NORMAL}"
}

# ===== [8] Homebrew セットアップ =====
install_homebrew() {
    if command -v brew &>/dev/null; then
        info_msg "Homebrew すでにインストール済み: $(brew --version | head -1)"
        brew update
        return
    fi
    loading "Homebrew をインストール中"
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    # Linux (Chromebook) の場合 PATH 追加
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        echo 'eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"' >> ~/.bashrc
        eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"
    fi
    echo "${GREEN}Homebrew インストール完了${NORMAL}"
}

brew_install_all() {
    install_homebrew

    loading "Go (最新) をインストール中"
    brew install go 2>/dev/null || brew upgrade go

    loading "Node.js 22 (LTS) をインストール中"
    brew install node@22 2>/dev/null || brew upgrade node@22
    brew link node@22 --force --overwrite 2>/dev/null || true

    loading "Python 3.12 をインストール中 (pyenv経由・Homebrewは使わない)"
    install_python312
    python3.12 -m pip install requests PyPDF2 Pillow watchdog --quiet 2>/dev/null || true

    loading "Neovim をインストール中"
    brew install neovim 2>/dev/null || brew upgrade neovim

    loading "開発ツールをインストール中"
    brew install ripgrep fd git starship 2>/dev/null || true

    python3.12 -m pip install requests PyPDF2 Pillow watchdog 2>/dev/null || \
    pip3 install requests PyPDF2 Pillow watchdog --break-system-packages 2>/dev/null || \
    pip3 install requests PyPDF2 Pillow watchdog

    echo "${GREEN}Homebrew 一括インストール完了！${NORMAL}"
    echo "  Go:     $(go version 2>/dev/null || echo '要ターミナル再起動')"
    echo "  Node:   $(node -v 2>/dev/null || echo '要ターミナル再起動')"
    echo "  Python: $(python3 --version 2>/dev/null)"
    echo "  Neovim: $(nvim --version 2>/dev/null | head -1 || echo '要ターミナル再起動')"
}

info_msg() { echo -e "${GREEN}[✓]${NC:-} $1"; }

# ===== [101] 全機能一括インストール =====
install_everything() {
    echo "${MAGENTA}${BOLD}"
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║         🚀 全機能一括インストール開始                    ║"
    echo "║  システム / Python 3.12 / Node.js 22 / Go / Docker       ║"
    echo "║  VSCode / Ngrok / Starship / ble.sh / Neovim 0.11        ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo "${NORMAL}"

    # ── 1. システム基本パッケージ ──
    step_msg "1/10 システム更新 & 基本パッケージ"
    sudo apt-get update -qq && sudo apt-get upgrade -y
    sudo apt-get install -y \
        curl wget git unzip build-essential \
        ripgrep fd-find gawk make \
        software-properties-common ca-certificates gnupg lsb-release \
        libmagic1

    # ── 2. Python 3.12 (pyenv経由・Debian/Chromebook対応) ──
    step_msg "2/10 Python 3.12 インストール"
    install_python312
    python3.12 -m pip install requests PyPDF2 Pillow watchdog --quiet 2>/dev/null || true
    echo "${GREEN}  Python: $(python3.12 --version)${NORMAL}"

    # ── 3. Node.js 22 (nodesource) ──
    step_msg "3/10 Node.js 22 (LTS) インストール"
    curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
    sudo apt-get install -y nodejs
    echo "${GREEN}  Node: $(node -v)  npm: $(npm -v)${NORMAL}"

    # ── 4. Go 1.24.1 ──
    step_msg "4/10 Go 1.24.1 インストール"
    GO_VERSION="1.24.1"
    ARCH=$(uname -m); case "$ARCH" in x86_64) GA="amd64";; aarch64) GA="arm64";; *) GA="amd64";; esac
    wget -q "https://go.dev/dl/go${GO_VERSION}.linux-${GA}.tar.gz" -O /tmp/go.tar.gz
    sudo rm -rf /usr/local/go
    sudo tar -C /usr/local -xzf /tmp/go.tar.gz && rm /tmp/go.tar.gz
    export PATH=$PATH:/usr/local/go/bin
    grep -q '/usr/local/go/bin' ~/.bashrc || echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
    go install golang.org/x/tools/gopls@latest
    echo "${GREEN}  Go: $(go version)${NORMAL}"

    # ── 5. Docker ──
    step_msg "5/10 Docker インストール"
    if command -v docker &>/dev/null; then
        echo "${GREEN}  Docker すでにインストール済み: $(docker --version)${NORMAL}"
    else
        sudo install -m 0755 -d /etc/apt/keyrings
        curl -fsSL https://download.docker.com/linux/debian/gpg | \
            sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
        sudo chmod a+r /etc/apt/keyrings/docker.gpg
        echo \
            "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
            https://download.docker.com/linux/debian $(lsb_release -cs) stable" | \
            sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
        sudo apt-get update -qq
        sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
        sudo usermod -aG docker "$USER"
        echo "${GREEN}  Docker: $(docker --version)${NORMAL}"
    fi

    # ── 6. VSCode ──
    step_msg "6/10 VSCode インストール"
    if command -v code &>/dev/null; then
        echo "${GREEN}  VSCode すでにインストール済み${NORMAL}"
    else
        wget -qO- https://packages.microsoft.com/keys/microsoft.asc | \
            sudo gpg --dearmor -o /usr/share/keyrings/microsoft.gpg
        echo "deb [arch=amd64 signed-by=/usr/share/keyrings/microsoft.gpg] \
            https://packages.microsoft.com/repos/code stable main" | \
            sudo tee /etc/apt/sources.list.d/vscode.list > /dev/null
        sudo apt-get update -qq && sudo apt-get install -y code
        echo "${GREEN}  VSCode インストール完了${NORMAL}"
    fi

    # ── 7. Ngrok ──
    step_msg "7/10 Ngrok インストール"
    if command -v ngrok &>/dev/null; then
        echo "${GREEN}  Ngrok すでにインストール済み${NORMAL}"
    else
        curl -sSL https://ngrok-agent.s3.amazonaws.com/ngrok.asc | \
            sudo tee /etc/apt/trusted.gpg.d/ngrok.asc >/dev/null
        echo "deb https://ngrok-agent.s3.amazonaws.com bookworm main" | \
            sudo tee /etc/apt/sources.list.d/ngrok.list
        sudo apt-get update -qq && sudo apt-get install -y ngrok
        echo "${GREEN}  Ngrok インストール完了${NORMAL}"
        echo "${YELLOW}  ※ Authtoken は後で: ngrok config add-authtoken <TOKEN>${NORMAL}"
    fi

    # ── 8. Homebrew ──
    step_msg "8/10 Homebrew インストール"
    if command -v brew &>/dev/null; then
        echo "${GREEN}  Homebrew すでにインストール済み${NORMAL}"
        brew update --quiet
    else
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        echo 'eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"' >> ~/.bashrc
        eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"
        echo "${GREEN}  Homebrew インストール完了${NORMAL}"
    fi

    # ── 9. Starship + ble.sh ──
    step_msg "9/10 Starship + ble.sh インストール"
    install_shell_enhancements

    # ── 10. Neovim 0.11 IDE ──
    step_msg "10/10 Neovim 0.11 IDE セットアップ"
    # Neovimバイナリ
    ARCH=$(uname -m); case "$ARCH" in x86_64) NA="x86_64";; aarch64) NA="arm64";; *) NA="x86_64";; esac
    curl -LO "https://github.com/neovim/neovim/releases/latest/download/nvim-linux-${NA}.tar.gz"
    sudo rm -rf /opt/nvim && sudo mkdir -p /opt/nvim
    sudo tar -C /opt/nvim -xzf "nvim-linux-${NA}.tar.gz" --strip-components=1
    sudo ln -sf /opt/nvim/bin/nvim /usr/local/bin/nvim
    rm "nvim-linux-${NA}.tar.gz"
    # fd エイリアス
    [ ! -x "$(command -v fd)" ] && [ -x "$(command -v fdfind)" ] && \
        sudo ln -sf /usr/bin/fdfind /usr/local/bin/fd
    write_nvim_files
    echo "${GREEN}  Neovim: $(nvim --version | head -1)${NORMAL}"

    # ── 完了サマリー ──
    echo ""
    echo "${MAGENTA}${BOLD}╔══════════════════════════════════════════════════════════╗"
    echo "║               ✅ 全インストール完了！                    ║"
    echo "╚══════════════════════════════════════════════════════════╝${NORMAL}"
    echo ""
    echo "  Python : $(python3 --version)"
    echo "  Node   : $(node -v 2>/dev/null || echo '要ターミナル再起動')"
    echo "  Go     : $(go version 2>/dev/null || echo '要ターミナル再起動')"
    echo "  Docker : $(docker --version 2>/dev/null || echo '要ターミナル再起動')"
    echo "  Neovim : $(nvim --version 2>/dev/null | head -1 || echo '要ターミナル再起動')"
    echo ""
    echo "${YELLOW}⚠ 変更を完全反映するにはターミナルを再起動してください${NORMAL}"
    echo "${YELLOW}⚠ Docker を sudo なしで使うにはログアウト→再ログインが必要です${NORMAL}"
}

step_msg() { echo -e "\n${CYAN}[$1]${NORMAL}"; }


while true; do
    print_header
    echo "${CYAN}[1] システム    ${NORMAL}1: 更新  2: ストレージ  3: ネットワーク"
    echo "${YELLOW}[2] Python      ${NORMAL}10: インストール  11: 仮想環境  12: Pip  13: 実行"
    echo "${GREEN}[3] Node.js     ${NORMAL}20: インストール  21: Express作成  23: ポート解放"
    echo "${BLUE}[4] Git/File    ${NORMAL}30: Git設定  32: Git状況  40: 検索  42: バックアップ"
    echo "${MAGENTA}[5] ツール      ${NORMAL}50: VSCode  60: Ngrok"
    echo "──────────────────────────────────────────────────────────"
    echo "${BOLD}${BLUE}[6] 最先端シェル & IDE構築${NORMAL}"
    echo "    70: ${BOLD}シェルUI強化 (Starship + ble.sh)${NORMAL}"
    echo "    80: ${BOLD}Neovim 0.11 IDE 完全セットアップ${NORMAL}"
    echo "──────────────────────────────────────────────────────────"
    echo "${GREEN}[7] Homebrew${NORMAL}"
    echo "    90: ${BOLD}Homebrew インストール${NORMAL}"
    echo "    91: ${BOLD}Go + Node.js 22 + Python 3.12 + Neovim 一括インストール${NORMAL}"
    echo "──────────────────────────────────────────────────────────"
    echo "${MAGENTA}${BOLD}101: 🚀 全機能一括インストール (Python3.12/Node22/Go/Docker/VSCode/Ngrok/Neovim)${NORMAL}"
    echo "──────────────────────────────────────────────────────────"
    echo "${RED}99: 終了${NORMAL}"
    echo ""
    read -r -p "${BOLD}メニュー番号を入力してください > ${NORMAL}" sel || sel=""

    case "$sel" in
        1) system_update ;; 2) disk_status ;; 3) network_info ;;
        10) python_install ;; 11) create_venv ;; 12) pip_install ;; 13) run_python ;;
        20) node_install ;; 21) create_express ;; 23) kill_node ;;
        30) git_setup ;; 32) git status ;; 40) file_search ;; 42) backup_home ;;
        50) install_vscode ;; 60) install_ngrok ;;
        70) install_shell_enhancements ;; 80) setup_nvim_ide ;;
        90) install_homebrew ;; 91) brew_install_all ;;
        101) install_everything ;;
        99) echo "${MAGENTA}お疲れ様でした！${NORMAL}"; exit 0 ;;
        *) echo "${RED}無効な入力です。${NORMAL}" ;;
    esac
    pause
done
