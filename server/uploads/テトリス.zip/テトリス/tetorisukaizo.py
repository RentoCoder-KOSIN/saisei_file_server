import pygame
import random
from helper import *
# --- 基本設定 ---
CELL = 30
COLS = 10
ROWS = 20
INFO_HEIGHT = 60
WIDTH = COLS * CELL
HEIGHT = ROWS * CELL + INFO_HEIGHT
FPS = 60

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# --- 色 ---
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
CYAN = (0, 255, 255)

# --- フィールド ---
field = [[0 for _ in range(COLS)] for _ in range(ROWS)]

# --- テトリミノ（I型だけ） ---
blocks = [
    [[1, 1, 1, 1]],
    
    #L
    [
        [1, 1, 1, 1],
        [1, 0, 0, 0],
        [1, 0, 0, 0],
        [1, 0, 0, 0]
    ],

    [
        [1, 1, 0, 0],
        [1, 1, 0, 0],
    ],

]

# --- 現在のブロック ---
block = random.choice(blocks)
bx = COLS // 2 - len(block[0]) // 2
by = 0

score = 0
fall_timer = 0

current_scene = "Title" #Title or Game or GameOver


# --- 当たり判定 ---
def can_move(nx, ny, b):
    for y in range(len(b)):
        for x in range(len(b[0])):
            if b[y][x]:
                fx = nx + x
                fy = ny + y
                if fx < 0 or fx >= COLS or fy >= ROWS:
                    return False
                if fy >= 0 and field[fy][fx]:
                    return False
    return True

# --- 固定 ---
def fix_block():
    global block, bx, by
    for y in range(len(block)):
        for x in range(len(block[0])):
            if block[y][x]:
                field[by + y][bx + x] = 1
    clear_lines()
    block = random.choice(blocks)
    bx = COLS // 2 - len(block[0]) // 2
    by = 0

# --- ライン消去（ここが改造ポイント）---
def clear_lines():
    global score
    new_field = []
    cleared = 0

    for row in field:
        if all(row):
            cleared += 1
        else:
            new_field.append(row)

    for _ in range(cleared):
        new_field.insert(0, [0] * COLS)

    field[:] = new_field

    # ※ここはいじるな禁止ゾーン
    score += cleared * 100


# --- GameOver判定 ---
def is_game_over():
    for x in range(COLS):
        if field[0][x]:
            return True

# --- 描画 ---
def draw():
    screen.fill(BLACK)

    # フィールド
    for y in range(ROWS):
        for x in range(COLS):
            if field[y][x]:
                pygame.draw.rect(screen, CYAN,
                                 (x*CELL, y*CELL, CELL, CELL))

    # 落下中ブロック
    for y in range(len(block)):
        for x in range(len(block[0])):
            if block[y][x]:
                pygame.draw.rect(screen, (255, 255, 255),
                                 ((bx+x)*CELL, (by+y)*CELL, CELL, CELL))


    # --- スコア表示エリア ---
    pygame.draw.rect(screen, GRAY,
                     (0, ROWS * CELL, WIDTH, INFO_HEIGHT))

    draw_text(screen, f"Score : {score}", 10, ROWS * CELL + 15)


    pygame.display.update()
    pygame.display.update()

# --- メインループ ---
running = True
while running:
    clock.tick(FPS)


    if current_scene == "Title":
        draw_text(screen, "Press SPACE to Start", WIDTH // 2, HEIGHT // 2, font_size=40, center=True)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    current_scene = "Game"


    if current_scene == "Game":


        fall_timer += 1
        keys = pygame.key.get_pressed()

        if keys[pygame.K_DOWN]:
            if can_move(bx, by+1, block):
                by += 1


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_LEFT:
                    if can_move(bx-1, by, block):
                        bx -= 1
                if event.key == pygame.K_RIGHT:
                    if can_move(bx+1, by, block):
                        bx += 1

                if event.key == pygame.K_SPACE:

                    if current_scene == "Title":
                        current_scene = "Game"

                    if current_scene == "Game":
                        rotated = [list(row) for row in zip(*block[::-1])]
                        if can_move(bx, by, rotated):
                            block = rotated
                if current_scene == "GameOver":
                    field = [[0 for _ in range(COLS)] for _ in range(ROWS)]
                    score = 0
                    block = random.choice(blocks)
                    bx = COLS // 2 - len(block[0]) // 2
                    by = 0
                    current_scene = "Title"

        draw()

        draw_text(screen, f"Score: {score}", WIDTH // 2, 20, font_size=24)

    


    if is_game_over():
        current_scene = "GameOver"
        print("Game Over")

    # 自動落下
    if fall_timer > 30:
        fall_timer = 0
        if can_move(bx, by+1, block):
            by += 1
        else:
            fix_block()



pygame.quit()
