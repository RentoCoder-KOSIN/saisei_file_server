import pygame
import random
from helper import draw_text

# --- 基本設定 ---
CELL = 30
COLS = 10
ROWS = 20
INFO_HEIGHT = 60
WIDTH = COLS * CELL
HEIGHT = ROWS * CELL + INFO_HEIGHT
FPS = 60

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Tetris Lite")
clock = pygame.time.Clock()

# --- 色 ---
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
CYAN = (0, 255, 255)
WHITE = (255, 255, 255)

# --- フィールド ---
field = [[0 for _ in range(COLS)] for _ in range(ROWS)]

# --- テトリミノ ---
blocks = [

    # I
    [
        [1,1,1,1]
    ],

    # O
    [
        [1,1],
        [1,1]
    ],

    # T
    [
        [0,1,0],
        [1,1,1]
    ],

    # S
    [
        [0,1,1],
        [1,1,0]
    ],

    # Z
    [
        [1,1,0],
        [0,1,1]
    ],

    # J
    [
        [1,0,0],
        [1,1,1]
    ],

    # L
    [
        [0,0,1],
        [1,1,1]
    ],
]

# --- Item ---
items = [
    {"shape": [[1]], "color": (255, 215, 0), "effect": "BOMB"},
    {"shape": [[1]], "color": (0, 255, 0), "effect": "CLEAR_ROW"},
    #{"shape": [[1]], "color": (255, 0, 255), "effect": "SLOW_FALL"}
]

# --- 現在のブロック ---
def new_block():
    if random.random() < 0.1:
        item = random.choice(items)
        return item["shape"], COLS // 2 - len(item["shape"][0]) // 2, 0, item
    else:
        b = random.choice(blocks)
        bx = COLS // 2 - len(b[0]) // 2
        by = 0
        return b, bx, by, None

next_block, _, _, next_item = new_block()
block, bx, by, current_item = new_block()
score = 0
fall_timer = 0
fall_speed = 30  # フレーム数

PREVIEW_X = WIDTH - 120
PREVIEW_Y = 30
current_item, next_item = None, None
current_scene = "Title"  # Title / Game / GameOver

# --- 当たり判定 ---
def can_move(nx, ny, b):
    for y in range(len(b)):
        for x in range(len(b[0])):
            if b[y][x]:
                fx = nx + x
                fy = ny + y
                if fx < 0 or fx >= COLS or fy >= ROWS:
                    return False
                if fy >= 0 and field[fy][fx]:
                    return False
    return True

# --- 固定 ---
def fix_block():
    global block, next_block, bx, by, score
    global current_item, next_item
    for y in range(len(block)):
        for x in range(len(block[0])):
            if block[y][x]:
                field[by + y][bx + x] = 1

    if current_item:
        if current_item["effect"] == "BOMB":
            bomb(bx, by)
        elif current_item["effect"] == "CLEAR_ROW":
            clear_lines()
        # elif current_item["effect"] == "SLOW_FALL":
        #     slow_down()

    clear_lines()

    block = next_block
    current_item = next_item
    bx = COLS // 2 - len(block[0]) // 2
    by = 0

    next_block, _, _, next_item = new_block()


def bomb(cx, cy):
    global score
    for y in range(cy - 1, cy + 2):
        for x in range(cx - 1, cx + 2):
            if 0 <= x < COLS and 0 <= y < ROWS:
                if field[y][x]:
                    field[y][x] = 0
                    score += 10

def slow_down():
    global fall_speed
    fall_speed += 10
    if fall_speed > 60:
        fall_speed = 60


# --- ライン消去 ---
def clear_lines():
    global score
    new_field = []
    cleared = 0
    for row in field:
        if all(row):
            cleared += 1
        else:
            new_field.append(row)
    for _ in range(cleared):
        new_field.insert(0, [0] * COLS)
    field[:] = new_field
    score += cleared * 100  #Don't Change

# --- GHOST_BLOCK
def preview_block():
    ghost_y = by
    while can_move(bx, ghost_y + 1, block):
        ghost_y += 1

    for y in range(len(block)):
        for x in range(len(block[0])):
            if block[y][x]:
                pygame.draw.rect(screen, (100, 100, 100), ((bx+x)*CELL, (ghost_y+y)*CELL, CELL, CELL))
                pygame.draw.rect(screen, GRAY, ((bx+x)*CELL, (ghost_y+y)*CELL, CELL, CELL), 1)

# --- ゲームオーバー判定 ---
def is_game_over():
    for x in range(COLS):
        if field[0][x]:
            return True
    return False

# --- 描画 ---
def draw():
    screen.fill(BLACK)

    # フィールド
    for y in range(ROWS):
        for x in range(COLS):
            if field[y][x]:
                pygame.draw.rect(screen, CYAN,
                                 (x*CELL, y*CELL, CELL, CELL))
                pygame.draw.rect(screen, GRAY,
                                 (x*CELL, y*CELL, CELL, CELL), 1)


    # 落下中ブロック
    for y in range(len(block)):
        for x in range(len(block[0])):
            if block[y][x]:
                if current_item:              # アイテムなら色を反映
                    color = current_item["color"]
                else:
                    color = WHITE
                pygame.draw.rect(screen, color,
                                ((bx+x)*CELL, (by+y)*CELL, CELL, CELL))
                pygame.draw.rect(screen, GRAY,
                                ((bx+x)*CELL, (by+y)*CELL, CELL, CELL), 1)


    preview_block()

    # スコア表示エリア
    pygame.draw.rect(screen, GRAY,
                     (0, ROWS*CELL, WIDTH, INFO_HEIGHT))
    draw_text(screen, f"Score: {score}", 10, ROWS*CELL + 15)
    
    # NEXT BLOCK
    draw_text(screen, "NEXT", WIDTH - 110, 10)

    for y in range(len(next_block)):
        for x in range(len(next_block[0])):
            if next_block[y][x]:
                if next_item:                 #色を反映
                    color = next_item["color"]
                else:
                    color = WHITE
                pygame.draw.rect(
                    screen,
                    color,
                    (WIDTH - 120 + x*CELL, 30 + y*CELL, CELL, CELL)
                )

    
    
    
    pygame.display.update()


# --- メインループ ---
running = True
while running:
    clock.tick(FPS)
    keys = pygame.key.get_pressed()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if current_scene == "Title":
                if event.key == pygame.K_SPACE:
                    current_scene = "Game"
                    field = [[0 for _ in range(COLS)] for _ in range(ROWS)]
                    score = 0
                    next_block, _, _, next_item = new_block()
                    block, bx, by, current_item = new_block()

            elif current_scene == "Game":
                if event.key == pygame.K_LEFT and can_move(bx-1, by, block):
                    bx -= 1
                if event.key == pygame.K_RIGHT and can_move(bx+1, by, block):
                    bx += 1
                if event.key == pygame.K_SPACE:
                    rotated = [list(row) for row in zip(*block[::-1])]
                    if can_move(bx, by, rotated):
                        block = rotated

            elif current_scene == "GameOver":
                if event.key == pygame.K_SPACE:
                    current_scene = "Title"

    if current_scene == "Title":
        screen.fill(BLACK)
        draw_text(screen, "TETRIS LITE", WIDTH//2, HEIGHT//2 - 50, font_size=60, center=True)
        draw_text(screen, "Press SPACE to Start", WIDTH//2, HEIGHT//2 + 20, font_size=30, center=True)
        pygame.display.update()

    elif current_scene == "Game":
        # 自動落下
        fall_timer += 1
        if fall_timer > fall_speed:
            fall_timer = 0
            if can_move(bx, by+1, block):
                by += 1
            else:
                fix_block()
                if is_game_over():
                    current_scene = "GameOver"

        draw()

    elif current_scene == "GameOver":
        screen.fill(BLACK)
        draw_text(screen, "GAME OVER", WIDTH//2, HEIGHT//2 - 50, font_size=60, center=True)
        draw_text(screen, f"Score: {score}", WIDTH//2, HEIGHT//2 + 20, font_size=30, center=True)
        draw_text(screen, "Press SPACE to Return to Title", WIDTH//2, HEIGHT//2 + 60, font_size=20, center=True)
        pygame.display.update()

pygame.quit()
