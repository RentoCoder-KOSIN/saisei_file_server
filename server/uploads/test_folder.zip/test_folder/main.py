print("Hello from Pylab!")
print("1 + 1 =", 1+1)
