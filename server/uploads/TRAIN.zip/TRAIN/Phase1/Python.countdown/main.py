import time

count = int(input("カウントダウンの開始数を入力してください: "))

for i in range(count, 0, -1):
    print(i)
    time.sleep(1)
print("発射!")
