package main

import (
	"fmt"
	"errors"
)

func add(a, b float64) float64 {
	return a + b
}

func subtract(a, b float64) float64 {
	return a - b
}

func multiply(a, b float64) float64 {
	return a * b
}

func divide(a, b float64) (float64, error) {
	if b == 0 {
		return 0, errors.New("ゼロ除算エラー：0では割れません")
	}
	return a / b, nil
}

func calculate(a float64, op string, b float64) (float64, error) {
	switch op {
	case "+":
		return add(a, b), nil
	case "-":
		return subtract(a, b), nil
	case "*":
		return multiply(a, b), nil
	case "/":
		return divide(a, b)
	default:
		return 0, fmt.Errorf("不正な演算子です: %s", op)
	}
}

func main() {
	var a, b float64
	var op string

	fmt.Print("最初の数を入力してください: ")
	fmt.Scan(&a)

	fmt.Print("演算子を入力してください (+, -, *, /): ")
	fmt.Scan(&op)

	fmt.Print("次の数を入力してください: ")
	fmt.Scan(&b)

	result, err := calculate(a, op, b)
	if err != nil {
		fmt.Println("エラー:", err)
		return
	}

	fmt.Printf("%.2f %s %.2f = %.2f\n", a, op, b, result)
}
