package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
)

type Record struct {
    Title   string  `json:"title"`
    Amount  int     `json:"amount"`
    Date    string  `json:"date"`
}

const fileName = "records.json"

// input data
var records = []Record{
    {Title: "lunch", Amount: -800, Date: "2026-03-12"},
    {Title: "salary", Amount: 2600, Date: "2026-03-12"},
}

func saveRecords() error {
    data, err := json.MarshalIndent(records, "", "    ")
    if err != nil {
        return err
    }
    return os.WriteFile(fileName, data, 0644)
}

func loadRecords() {
    data, err := os.ReadFile(fileName)
    if err != nil {
        return
    }
    json.Unmarshal(data, &records)
}

func addHandler(w http.ResponseWriter, r *http.Request) {
    var record Record
    json.NewDecoder(r.Body).Decode(&record)
    records = append(records, record)
    saveRecords()
    fmt.Fprintf(w, "added menu: %s", record.Title)
}

func listHandler(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(records)
}

func summaryHandler(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Content-Type", "application/json")
    total := 0
    for _, record := range records {
        total += record.Amount
    }
    json.NewEncoder(w).Encode(map[string]int{"total": total})
}

func main() {
    loadRecords()
    http.HandleFunc("/add", addHandler)
    http.HandleFunc("/list", listHandler)
    http.HandleFunc("/summary", summaryHandler)
    fmt.Println("Open the server port :8080")
    http.ListenAndServe(":8080", nil)
}