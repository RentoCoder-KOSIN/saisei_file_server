import requests
BASE_URL = "http://server:8080"

def add():
    title = input("Title: ")
    amount = int(input("Amount: "))
    date = input("Date: ")
    res = requests.post(f"{BASE_URL}/add", json={
        "title": title,
        "amount": amount,
        "date": date
    })
    
    print("✅", res.text) 
    
def list_records():
    res = requests.get(f"{BASE_URL}/list")
    for i, record in enumerate(res.json(), 1):
            print(f"{i}. {record['title']} | {record['amount']}円 | {record['date']}")
    
def summary():
    res = requests.get(f"{BASE_URL}/summary")
    print(f"💰 合計: {res.json()['total']}円")

while True:
    cmd = input("cmd (add/list/summary/quit): ")
    if cmd == "add":
        add()
    elif cmd == "list":
        list_records()
    elif cmd == "summary":
        summary()
    elif cmd == "quit":
        print("goodbye!")
        break
    else:
        print(f"{cmd} not found.")