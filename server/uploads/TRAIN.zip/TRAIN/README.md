# 🚀 スキルアップロードマップ：Docker × Go × Python

> **対象者：** 初心者 ／ **目的：** 趣味・学習・個人プロジェクト・副業・業務改善  
> **方針：** 3技術をバランスよく、実際に手を動かしながら習得する

---

## ⏱ 全体スケジュール（目安：6〜9ヶ月）

| フェーズ | 期間 | テーマ |
|--------|------|--------|
| Phase 1 | 1〜2ヶ月 | 各技術の基礎を個別に習得 |
| Phase 2 | 2〜3ヶ月 | 3技術を組み合わせた小さなアプリを作る |
| Phase 3 | 3〜4ヶ月 | 実用的なプロジェクトを完成させる |

---

## 📦 Phase 1：基礎習得（1〜2ヶ月）

### 🐍 Python 基礎（2〜3週間）

**目標：** スクリプトが書けて、ライブラリが使える状態に

| ステップ | 内容 | 成果物 |
|--------|------|-------|
| 1 | 変数・条件分岐・ループ・関数 | FizzBuzz、簡単な計算スクリプト |
| 2 | リスト・辞書・ファイル操作 | CSVを読み込んで処理するスクリプト |
| 3 | 外部ライブラリ（requests, pandas）| Web APIからデータ取得→CSV保存 |
| 4 | 仮想環境（venv）, pip | パッケージ管理の習慣づけ |

**おすすめ練習：**
```python
# 天気APIからデータ取得してファイルに保存するスクリプト
import requests, json
response = requests.get("https://wttr.in/Tokyo?format=j1")
data = response.json()
print(f"東京の気温: {data['current_condition'][0]['temp_C']}℃")
```

---

### 🐹 Go 基礎（2〜3週間）

**目標：** シンプルなCLIツールが作れる状態に

| ステップ | 内容 | 成果物 |
|--------|------|-------|
| 1 | 型・変数・関数・ループ・if文 | Hello World、電卓CLI |
| 2 | 構造体・メソッド・インターフェース | ToDoリスト（CLI） |
| 3 | goroutine・channel（触りだけ） | 並行処理の概念理解 |
| 4 | `net/http`パッケージ | シンプルなHTTPサーバー |

**おすすめ練習：**
```go
// シンプルなHTTPサーバー（Hello World API）
package main

import (
    "fmt"
    "net/http"
)

func handler(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "Hello, World!")
}

func main() {
    http.HandleFunc("/", handler)
    http.ListenAndServe(":8080", nil)
}
```

---

### 🐳 Docker 基礎（1〜2週間）

**目標：** コンテナを起動・作成できる状態に

| ステップ | 内容 | 成果物 |
|--------|------|-------|
| 1 | Docker の概念（コンテナ vs VM） | 既存イメージを `docker run` で起動 |
| 2 | Dockerfile の書き方 | PythonアプリのDockerイメージ作成 |
| 3 | docker-compose の基礎 | 複数コンテナの連携 |
| 4 | ボリューム・ネットワーク | データの永続化 |

**おすすめ練習：**
```dockerfile
# Python スクリプトをDockerで動かす
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "main.py"]
```

---

## 🔗 Phase 2：3技術の連携（2〜3ヶ月）

### 🎯 ミニプロジェクト：「家計簿API」を作る

3技術を組み合わせた実践的なアプリを段階的に作ります。

```
┌─────────────┐     HTTP      ┌─────────────┐     ファイル    ┌─────────────┐
│   Python    │ ─────────── ▶ │   Go API    │ ─────────── ▶ │    JSON     │
│（データ入力）│              │（バックエンド）│              │  (データ保存) │
└─────────────┘              └─────────────┘              └─────────────┘
         ↑                         ↑
         └──── Docker Compose ──────┘
              （全部まとめて起動）
```

| 週 | 作業 | 技術 |
|----|------|------|
| 1〜2 | GoでREST APIを作る（収支の登録・取得） | Go + net/http |
| 3〜4 | PythonでAPIクライアントを作る（データ入力スクリプト） | Python + requests |
| 5〜6 | Docker化する（Dockerfile + docker-compose.yml） | Docker |
| 7〜8 | docker-compose up 一発で全部起動できる状態に | Docker Compose |

---

### 📚 この時期に学ぶと良いこと

**Go：**
- JSON の読み書き（`encoding/json`）
- エラーハンドリングのパターン
- `gorilla/mux` などのルーターライブラリ

**Python：**
- 例外処理（try/except）
- `argparse` でCLIツール化
- `dotenv` で環境変数管理

**Docker：**
- マルチステージビルド（Goのビルドに有効）
- `.dockerignore` の活用
- 環境変数の渡し方（`-e`, `env_file`）

---

## 🏆 Phase 3：実用プロジェクト（3〜4ヶ月）

### プロジェクト候補（1つ選んで作り込む）

#### 💰 A. 副業・業務改善向け：「データ集計ダッシュボード」
```
Python（スクレイピング/CSV処理）
  → Go（集計APIサーバー）
  → Docker（本番環境にデプロイ）
```

#### 🤖 B. 趣味・学習向け：「Botシステム」
```
Python（LINEbot / Discordbot のロジック）
  → Go（Webhook受け取りサーバー）
  → Docker（24時間稼働）
```

#### 📦 C. 業務改善向け：「ファイル自動処理ツール」
```
Python（Excel/PDF 処理）
  → Go（スケジューラー / CLIツール）
  → Docker（どの環境でも同じ動作）
```

---

## 🛠 開発環境のセットアップ（最初にやること）

```bash
# 1. Docker Desktop インストール
#    https://www.docker.com/products/docker-desktop/

# 2. Go インストール
#    https://go.dev/dl/

# 3. Python インストール（pyenv推奨）
#    https://github.com/pyenv/pyenv

# 4. エディタ：VS Code + 拡張機能
#    - Go（公式）
#    - Python（公式）
#    - Docker（公式）
#    - REST Client（API テスト用）
```

---

## 📖 おすすめ学習リソース

### Python
| リソース | 特徴 |
|---------|------|
| [Python公式チュートリアル](https://docs.python.org/ja/3/tutorial/) | 日本語・無料・網羅的 |
| paizaラーニング | ブラウザで動かせる・初心者向け |
| 『Pythonクラッシュコース』 | 実践的な入門書 |

### Go
| リソース | 特徴 |
|---------|------|
| [A Tour of Go](https://go.dev/tour/) | 公式・インタラクティブ・無料 |
| [Go by Example](https://gobyexample.com/) | 実例多数・リファレンスにも |
| 『実用 Go 言語』 | 日本語・実践向け |

### Docker
| リソース | 特徴 |
|---------|------|
| [Docker 公式 Get Started](https://docs.docker.com/get-started/) | ハンズオン形式 |
| [Play with Docker](https://labs.play-with-docker.com/) | ブラウザ上で練習できる |
| Udemy「Docker + Kubernetes」 | セール時に1,500円程度 |

---

## ✅ 習得チェックリスト

### Phase 1 完了の目安
- [ ] PythonでWebAPIを叩けてJSONをパースできる
- [ ] GoでHTTPサーバーが起動できる（ポート8080で `Hello`が返る）
- [ ] 自分で書いたPythonスクリプトをDockerで動かせる

### Phase 2 完了の目安
- [ ] Go APIにPythonからHTTPリクエストを送れる
- [ ] docker-compose.yml でGoとPythonのコンテナを同時起動できる
- [ ] 環境変数でDB接続情報などを切り替えられる

### Phase 3 完了の目安
- [ ] 実際に使えるアプリを1つ完成させた
- [ ] GitHubにコードを公開した
- [ ] READMEに使い方を書いた

---

## 💡 学習のコツ

1. **毎日30分でOK** — 継続が最重要。週末だけより毎日少しずつ
2. **エラーはコピペしてGoogle検索** — エラー文を読む習慣をつける
3. **動いたらGitHubにpush** — 進捗が見えてモチベ維持になる
4. **わからなくなったら戻る** — フェーズを行き来していい
5. **作るものを先に決める** — 「何を作るか」が学習の原動力になる

---

*作成日：2026年3月 ／ 対象技術：Docker × Go × Python*
